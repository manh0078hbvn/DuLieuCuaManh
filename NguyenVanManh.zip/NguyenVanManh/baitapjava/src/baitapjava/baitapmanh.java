/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package baitapjava;
import javax.swing.*;
/**
 *
 * @author HUBT
 */
public class baitapmanh extends javax.swing.JFrame {

    /**
     * Creates new form baitapmanh
     */
    public baitapmanh() {
        initComponents();
        setupModernHome();
    }

    /** Builds the welcome screen while keeping the NetBeans-generated menu actions. */
    private void setupModernHome() {
        final java.awt.Color navy = new java.awt.Color(20, 43, 76);
        final java.awt.Color blue = new java.awt.Color(37, 99, 180);
        final java.awt.Color ink = new java.awt.Color(35, 49, 66);
        final java.awt.Color muted = new java.awt.Color(111, 126, 145);
        final java.awt.Color canvas = new java.awt.Color(242, 246, 251);

        setTitle("Baitapjava | Qu\u1ea3n l\u00fd sinh vi\u00ean");
        setMinimumSize(new java.awt.Dimension(900, 600));
        setSize(1100, 700);
        setLocationRelativeTo(null);

        // Correct labels here too, so this screen remains readable if the old form
        // file was saved with a legacy character encoding.
        mnuHeThong.setText("H\u1ec7 th\u1ed1ng");
        mniDangNhap.setText("\u0110\u0103ng nh\u1eadp");
        mniThoat.setText("Tho\u00e1t");
        mnuQuanLy.setText("Qu\u1ea3n l\u00fd");
        mniKhoa.setText("Qu\u1ea3n l\u00fd khoa");
        mniMonHoc.setText("Qu\u1ea3n l\u00fd m\u00f4n h\u1ecdc");
        mniSinhVien.setText("Qu\u1ea3n l\u00fd sinh vi\u00ean");
        mniKetQua.setText("Qu\u1ea3n l\u00fd k\u1ebft qu\u1ea3");
        mnuTraCuu.setText("Tra c\u1ee9u");
        mniTraCuu.setText("Sinh vi\u00ean theo khoa");
        mnuTroGiup.setText("Tr\u1ee3 gi\u00fap");
        mniGioiThieu.setText("Gi\u1edbi thi\u1ec7u");

        jMenuBar1.setBackground(java.awt.Color.WHITE);
        jMenuBar1.setBorder(javax.swing.BorderFactory.createEmptyBorder(7, 14, 7, 14));
        for (javax.swing.JMenu menu : new javax.swing.JMenu[] {mnuHeThong, mnuQuanLy, mnuTraCuu, mnuTroGiup}) {
            menu.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 14));
            menu.setForeground(navy);
            menu.setBorder(javax.swing.BorderFactory.createEmptyBorder(4, 10, 4, 10));
        }

        javax.swing.JPanel page = new javax.swing.JPanel(new java.awt.BorderLayout(0, 25));
        page.setBackground(canvas);
        page.setBorder(javax.swing.BorderFactory.createEmptyBorder(34, 48, 28, 48));

        javax.swing.JPanel intro = new javax.swing.JPanel();
        intro.setOpaque(false);
        intro.setLayout(new javax.swing.BoxLayout(intro, javax.swing.BoxLayout.Y_AXIS));
        javax.swing.JLabel eyebrow = new javax.swing.JLabel("C\u1ed4NG TH\u00d4NG TIN \u0110\u00c0O T\u1ea0O");
        eyebrow.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 12));
        eyebrow.setForeground(blue);
        javax.swing.JLabel title = new javax.swing.JLabel("H\u1ec6 TH\u1ed0NG QU\u1ea2N L\u00dd SINH VI\u00caN");
        title.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 28));
        title.setForeground(navy);
        title.setBorder(javax.swing.BorderFactory.createEmptyBorder(8, 0, 5, 0));
        javax.swing.JLabel subtitle = new javax.swing.JLabel("Qu\u1ea3n l\u00fd th\u00f4ng tin sinh vi\u00ean, m\u00f4n h\u1ecdc v\u00e0 k\u1ebft qu\u1ea3 h\u1ecdc t\u1eadp.");
        subtitle.setFont(new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 15));
        subtitle.setForeground(muted);
        intro.add(eyebrow);
        intro.add(title);
        intro.add(subtitle);
        page.add(intro, java.awt.BorderLayout.NORTH);

        javax.swing.JPanel cards = new javax.swing.JPanel(new java.awt.GridLayout(2, 2, 18, 18));
        cards.setOpaque(false);
        cards.add(makeHomeCard("01", "Qu\u1ea3n l\u00fd khoa", "Danh s\u00e1ch khoa v\u00e0 th\u00f4ng tin chuy\u00ean ng\u00e0nh", blue, () -> mniKhoa.doClick()));
        cards.add(makeHomeCard("02", "Qu\u1ea3n l\u00fd m\u00f4n h\u1ecdc", "C\u1eadp nh\u1eadt danh m\u1ee5c m\u00f4n h\u1ecdc", new java.awt.Color(13, 148, 136), () -> mniMonHoc.doClick()));
        cards.add(makeHomeCard("03", "Qu\u1ea3n l\u00fd sinh vi\u00ean", "H\u1ed3 s\u01a1 v\u00e0 th\u00f4ng tin sinh vi\u00ean", new java.awt.Color(124, 92, 198), () -> mniSinhVien.doClick()));
        cards.add(makeHomeCard("04", "K\u1ebft qu\u1ea3 h\u1ecdc t\u1eadp", "Theo d\u00f5i k\u1ebft qu\u1ea3 theo sinh vi\u00ean v\u00e0 m\u00f4n h\u1ecdc", new java.awt.Color(220, 137, 48), () -> mniKetQua.doClick()));
        page.add(cards, java.awt.BorderLayout.CENTER);

        javax.swing.JPanel footer = new javax.swing.JPanel(new java.awt.BorderLayout());
        footer.setOpaque(false);
        javax.swing.JLabel hint = new javax.swing.JLabel("Ch\u1ecdn m\u1ee5c qu\u1ea3n l\u00fd \u0111\u1ec3 b\u1eaft \u0111\u1ea7u");
        hint.setFont(new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 13));
        hint.setForeground(muted);
        javax.swing.JLabel status = new javax.swing.JLabel("\u25cf  S\u1eb5n s\u00e0ng");
        status.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 12));
        status.setForeground(new java.awt.Color(30, 142, 96));
        footer.add(hint, java.awt.BorderLayout.WEST);
        footer.add(status, java.awt.BorderLayout.EAST);
        page.add(footer, java.awt.BorderLayout.SOUTH);

        setContentPane(page);
        getContentPane().setBackground(canvas);
    }

    private javax.swing.JPanel makeHomeCard(String number, String heading, String description,
            java.awt.Color accent, Runnable action) {
        javax.swing.JPanel card = new javax.swing.JPanel(new java.awt.BorderLayout(14, 8));
        card.setBackground(java.awt.Color.WHITE);
        card.setBorder(javax.swing.BorderFactory.createCompoundBorder(
                javax.swing.BorderFactory.createMatteBorder(0, 5, 0, 0, accent),
                javax.swing.BorderFactory.createEmptyBorder(20, 20, 20, 20)));
        card.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.JLabel badge = new javax.swing.JLabel(number, javax.swing.SwingConstants.CENTER);
        badge.setOpaque(true);
        badge.setBackground(new java.awt.Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 24));
        badge.setForeground(accent);
        badge.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 17));
        badge.setPreferredSize(new java.awt.Dimension(48, 48));
        card.add(badge, java.awt.BorderLayout.WEST);

        javax.swing.JPanel copy = new javax.swing.JPanel();
        copy.setOpaque(false);
        copy.setLayout(new javax.swing.BoxLayout(copy, javax.swing.BoxLayout.Y_AXIS));
        javax.swing.JLabel title = new javax.swing.JLabel(heading);
        title.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 17));
        title.setForeground(new java.awt.Color(35, 49, 66));
        javax.swing.JLabel detail = new javax.swing.JLabel("<html><div style='width:250px'>" + description + "</div></html>");
        detail.setFont(new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 13));
        detail.setForeground(new java.awt.Color(111, 126, 145));
        detail.setBorder(javax.swing.BorderFactory.createEmptyBorder(7, 0, 0, 0));
        copy.add(title);
        copy.add(detail);
        card.add(copy, java.awt.BorderLayout.CENTER);

        card.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseClicked(java.awt.event.MouseEvent event) { action.run(); }
            @Override public void mouseEntered(java.awt.event.MouseEvent event) {
                card.setBackground(new java.awt.Color(248, 251, 255));
                card.setBorder(javax.swing.BorderFactory.createCompoundBorder(
                        javax.swing.BorderFactory.createMatteBorder(0, 5, 0, 0, accent.darker()),
                        javax.swing.BorderFactory.createEmptyBorder(20, 20, 20, 20)));
            }
            @Override public void mouseExited(java.awt.event.MouseEvent event) {
                card.setBackground(java.awt.Color.WHITE);
                card.setBorder(javax.swing.BorderFactory.createCompoundBorder(
                        javax.swing.BorderFactory.createMatteBorder(0, 5, 0, 0, accent),
                        javax.swing.BorderFactory.createEmptyBorder(20, 20, 20, 20)));
            }
        });
        return card;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuItem8 = new javax.swing.JMenuItem();
        jLabel1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        mnuHeThong = new javax.swing.JMenu();
        mniDangNhap = new javax.swing.JMenuItem();
        mniThoat = new javax.swing.JMenuItem();
        mnuQuanLy = new javax.swing.JMenu();
        mniKhoa = new javax.swing.JMenuItem();
        mniMonHoc = new javax.swing.JMenuItem();
        mniSinhVien = new javax.swing.JMenuItem();
        mniKetQua = new javax.swing.JMenuItem();
        mnuTroGiup = new javax.swing.JMenu();
        mniGioiThieu = new javax.swing.JMenuItem();
        mnuTraCuu = new javax.swing.JMenu();
        mniTraCuu = new javax.swing.JMenuItem();

        jMenuItem8.setText("jMenuItem8");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel1.setText("Hệ Thống Quản Lý");

        mnuHeThong.setText("Hệ thống ");

        mniDangNhap.setText("Đăng nhập");
        mniDangNhap.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniDangNhapActionPerformed(evt);
            }
        });
        mnuHeThong.add(mniDangNhap);

        mniThoat.setText("Thoát");
        mniThoat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniThoatActionPerformed(evt);
            }
        });
        mnuHeThong.add(mniThoat);

        jMenuBar1.add(mnuHeThong);

        mnuQuanLy.setText("Quản lý ");

        mniKhoa.setText("Quản lý khoa");
        mniKhoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniKhoaActionPerformed(evt);
            }
        });
        mnuQuanLy.add(mniKhoa);

        mniMonHoc.setText("Quản lý môn học");
        mniMonHoc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniMonHocActionPerformed(evt);
            }
        });
        mnuQuanLy.add(mniMonHoc);

        mniSinhVien.setText("Quản lý sinh viên");
        mniSinhVien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniSinhVienActionPerformed(evt);
            }
        });
        mnuQuanLy.add(mniSinhVien);

        mniKetQua.setText("Quản lý kết quả");
        mniKetQua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniKetQuaActionPerformed(evt);
            }
        });
        mnuQuanLy.add(mniKetQua);

        jMenuBar1.add(mnuQuanLy);

        mnuTroGiup.setText("Trợ giúp");

        mniGioiThieu.setText("Giới thiệu");
        mniGioiThieu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniGioiThieuActionPerformed(evt);
            }
        });
        mnuTroGiup.add(mniGioiThieu);

        jMenuBar1.add(mnuTroGiup);

        mnuTraCuu.setText("Tra cứu ");

        mniTraCuu.setText("Tra cứu sinh viên theo khoa");
        mniTraCuu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniTraCuuActionPerformed(evt);
            }
        });
        mnuTraCuu.add(mniTraCuu);

        jMenuBar1.add(mnuTraCuu);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(116, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(82, 82, 82))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(105, 105, 105)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(151, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void mniThoatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniThoatActionPerformed
int chon = JOptionPane.showConfirmDialog(
    this,
    "Bạn có muốn thoát chương trình?",
    "Xác nhận",
    JOptionPane.YES_NO_OPTION
);

if (chon == JOptionPane.YES_OPTION) {
    System.exit(0);
}
    }//GEN-LAST:event_mniThoatActionPerformed

    private void mniMonHocActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniMonHocActionPerformed
quanlymonhoc f = new quanlymonhoc();
f.setLocationRelativeTo(this);
f.setVisible(true);
    }//GEN-LAST:event_mniMonHocActionPerformed

    private void mniDangNhapActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniDangNhapActionPerformed
dangnhap f = new dangnhap();
f.setLocationRelativeTo(this);
f.setVisible(true);
    }//GEN-LAST:event_mniDangNhapActionPerformed

    private void mniKhoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniKhoaActionPerformed
quanlykhoa f = new quanlykhoa();
f.setLocationRelativeTo(this);
f.setVisible(true);
    }//GEN-LAST:event_mniKhoaActionPerformed

    private void mniSinhVienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniSinhVienActionPerformed
quanlysinhvien f = new quanlysinhvien();
f.setLocationRelativeTo(this);
f.setVisible(true);
    }//GEN-LAST:event_mniSinhVienActionPerformed

    private void mniKetQuaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniKetQuaActionPerformed
quanlyketqua f = new quanlyketqua();
f.setLocationRelativeTo(this);
f.setVisible(true);
    }//GEN-LAST:event_mniKetQuaActionPerformed

    private void mniTraCuuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniTraCuuActionPerformed
tracuusinhvientheokhoa f = new tracuusinhvientheokhoa();
f.setLocationRelativeTo(this);
f.setVisible(true);
    }//GEN-LAST:event_mniTraCuuActionPerformed

    private void mniGioiThieuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniGioiThieuActionPerformed
JOptionPane.showMessageDialog(
    this,
    "PHẦN MỀM QUẢN LÝ ĐIỂM SINH VIÊN\n"
    + "QLDIEM - Java Swing\n"
    + "Phiên bản 1.0",
    "Giới thiệu",
    JOptionPane.INFORMATION_MESSAGE
);
    }//GEN-LAST:event_mniGioiThieuActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(baitapmanh.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(baitapmanh.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(baitapmanh.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(baitapmanh.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new baitapmanh().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem8;
    private javax.swing.JMenuItem mniDangNhap;
    private javax.swing.JMenuItem mniGioiThieu;
    private javax.swing.JMenuItem mniKetQua;
    private javax.swing.JMenuItem mniKhoa;
    private javax.swing.JMenuItem mniMonHoc;
    private javax.swing.JMenuItem mniSinhVien;
    private javax.swing.JMenuItem mniThoat;
    private javax.swing.JMenuItem mniTraCuu;
    private javax.swing.JMenu mnuHeThong;
    private javax.swing.JMenu mnuQuanLy;
    private javax.swing.JMenu mnuTraCuu;
    private javax.swing.JMenu mnuTroGiup;
    // End of variables declaration//GEN-END:variables
}
